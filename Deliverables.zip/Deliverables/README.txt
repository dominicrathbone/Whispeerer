=====================================================================================================================
					WHISPEERER
=====================================================================================================================
					SOURCE CODE: 
			https://github.com/domr115/CI360-Mobile-App-Dev
=====================================================================================================================
				TO DEMO THE APPLICATION:
Requisites:
 - Two instances of an android emulator or device (preferably KitKat or higher).

Guide:
1. Install on both devices.
2. Open both applications
3. Click  voice or video chat button in Application A.
4. Enter Application B's session username where it says enter their username.
5. Click call button
=====================================================================================================================
